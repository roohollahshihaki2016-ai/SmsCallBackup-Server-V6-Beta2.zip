import hashlib
import hmac
import json
import os
import sqlite3
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, Header, HTTPException, Query, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

DB_PATH = os.getenv("DB_PATH", "/data/server.db")
MAX_PAYLOAD_BYTES = int(os.getenv("MAX_PAYLOAD_BYTES", "1048576"))
ONLINE_SECONDS = int(os.getenv("ONLINE_SECONDS", "90"))

# These are bootstrap credentials for a PRIVATE prototype only.
# Never reuse them, publish them, or deploy with example values.
DEVICE_TOKENS = {
    os.getenv("RECEIVER_TOKEN", "CHANGE_ME_RECEIVER"): ("receiver", "receiver"),
    os.getenv("SENDER_1_TOKEN", "CHANGE_ME_SENDER_1"): ("sender", "sender-1"),
    os.getenv("SENDER_2_TOKEN", "CHANGE_ME_SENDER_2"): ("sender", "sender-2"),
}

app = FastAPI(
    title="SMS & Call Backup Server V6 Beta",
    version="0.1.0",
    description="Private relay for encrypted device-to-device backup batches."
)

@contextmanager
def db():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        yield conn
        conn.commit()
    finally:
        conn.close()

def init_db():
    with db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS devices (
            device_key TEXT PRIMARY KEY,
            role TEXT NOT NULL,
            slot TEXT NOT NULL UNIQUE,
            last_seen INTEGER NOT NULL DEFAULT 0,
            enabled INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS enrollment_requests (
            request_id TEXT PRIMARY KEY,
            device_name TEXT NOT NULL,
            credential_hash TEXT NOT NULL UNIQUE,
            state TEXT NOT NULL DEFAULT 'pending',
            created_at INTEGER NOT NULL,
            decided_at INTEGER
        );
        CREATE INDEX IF NOT EXISTS idx_enrollments_state
            ON enrollment_requests(state, created_at);
        CREATE TABLE IF NOT EXISTS batches (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            batch_uuid TEXT NOT NULL UNIQUE,
            sender_slot TEXT NOT NULL,
            ciphertext TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            delivered INTEGER NOT NULL DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS idx_batches_delivery
            ON batches(delivered, id);
        """)
        for token, (role, slot) in DEVICE_TOKENS.items():
            if token.startswith("CHANGE_ME_"):
                continue
            conn.execute(
                """INSERT INTO devices(device_key, role, slot, last_seen, enabled)
                   VALUES(?, ?, ?, 0, 1)
                   ON CONFLICT(device_key) DO UPDATE SET role=excluded.role, slot=excluded.slot""",
                (hashlib.sha256(token.encode()).hexdigest(), role, slot)
            )

@app.on_event("startup")
def startup():
    init_db()

def authenticate(authorization: Optional[str]):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Bearer token required")
    supplied = authorization[7:].strip()
    supplied_hash = hashlib.sha256(supplied.encode()).hexdigest()
    matched = None
    for token, identity in DEVICE_TOKENS.items():
        if token.startswith("CHANGE_ME_"):
            continue
        expected_hash = hashlib.sha256(token.encode()).hexdigest()
        if hmac.compare_digest(supplied_hash, expected_hash):
            matched = identity
    with db() as conn:
        row = conn.execute(
            "SELECT role, slot, enabled FROM devices WHERE device_key=?",
            (supplied_hash,)
        ).fetchone()
        if row is None:
            raise HTTPException(status_code=401, detail="Invalid device credential")
        if not row["enabled"]:
            raise HTTPException(status_code=403, detail="Device disabled")
        # Database identity is authoritative, including Receiver-approved dynamic Senders.
        role, slot = row["role"], row["slot"]
        conn.execute("UPDATE devices SET last_seen=? WHERE device_key=?",
                     (int(time.time()), supplied_hash))
    return role, slot

class Heartbeat(BaseModel):
    app_version: str = Field(default="0.1.0", max_length=40)
    platform: str = Field(default="android", max_length=40)

class EncryptedBatch(BaseModel):
    batch_id: str = Field(min_length=8, max_length=80)
    ciphertext: str = Field(min_length=16)
    # The server stores ciphertext only. It must not receive plaintext SMS/call data.

class AckBody(BaseModel):
    batch_ids: list[str] = Field(min_length=1, max_length=200)

class ControlBody(BaseModel):
    sender_slot: str = Field(pattern=r"^sender-[12]$")
    enabled: bool

class EnrollmentBody(BaseModel):
    device_name: str = Field(min_length=1, max_length=60)
    # SHA-256 of a random 32-byte credential generated and kept by Sender.
    credential_hash: str = Field(pattern=r"^[0-9a-f]{64}$")

class EnrollmentDecision(BaseModel):
    pass

@app.get("/health")
def health():
    return {"ok": True, "service": "sms-call-backup-server", "version": "0.1.0"}

@app.post("/v1/enrollments")
def create_enrollment(body: EnrollmentBody):
    """Create a pending Sender request. No SMS/call data is accepted here."""
    name = " ".join(body.device_name.split())
    if not name:
        raise HTTPException(status_code=422, detail="Device name is required")
    now = int(time.time())
    request_id = str(uuid.uuid4())
    with db() as conn:
        # Expire old pending requests after 24 hours.
        conn.execute(
            "UPDATE enrollment_requests SET state='expired', decided_at=? "
            "WHERE state='pending' AND created_at<?",
            (now, now - 86400)
        )
        existing = conn.execute(
            "SELECT request_id, state FROM enrollment_requests WHERE credential_hash=?",
            (body.credential_hash,)
        ).fetchone()
        if existing:
            return {"ok": True, "request_id": existing["request_id"], "state": existing["state"]}
        pending_count = conn.execute(
            "SELECT COUNT(*) AS n FROM enrollment_requests WHERE state='pending'"
        ).fetchone()["n"]
        if pending_count >= 50:
            raise HTTPException(status_code=429, detail="Too many pending enrollment requests")
        conn.execute(
            "INSERT INTO enrollment_requests(request_id, device_name, credential_hash, state, created_at) "
            "VALUES(?, ?, ?, 'pending', ?)",
            (request_id, name, body.credential_hash, now)
        )
    return {"ok": True, "request_id": request_id, "state": "pending"}

@app.get("/v1/enrollments/{request_id}")
def enrollment_state(request_id: str, authorization: Optional[str] = Header(default=None)):
    """Sender checks its own request using the random credential it generated."""
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Bearer credential required")
    supplied_hash = hashlib.sha256(authorization[7:].strip().encode()).hexdigest()
    with db() as conn:
        row = conn.execute(
            "SELECT state FROM enrollment_requests WHERE request_id=? AND credential_hash=?",
            (request_id, supplied_hash)
        ).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Enrollment request not found")
    return {"ok": True, "state": row["state"]}

@app.get("/v1/enrollments")
def list_enrollments(authorization: Optional[str] = Header(default=None)):
    role, _ = authenticate(authorization)
    if role != "receiver":
        raise HTTPException(status_code=403, detail="Only receiver can view enrollment requests")
    with db() as conn:
        rows = conn.execute(
            "SELECT request_id, device_name, created_at FROM enrollment_requests "
            "WHERE state='pending' ORDER BY created_at"
        ).fetchall()
    return {"ok": True, "requests": [dict(row) for row in rows]}

@app.post("/v1/enrollments/{request_id}/approve")
def approve_enrollment(request_id: str, authorization: Optional[str] = Header(default=None)):
    role, _ = authenticate(authorization)
    if role != "receiver":
        raise HTTPException(status_code=403, detail="Only receiver can approve devices")
    with db() as conn:
        row = conn.execute(
            "SELECT credential_hash, state FROM enrollment_requests WHERE request_id=?",
            (request_id,)
        ).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Enrollment request not found")
        if row["state"] != "pending":
            raise HTTPException(status_code=409, detail="Request is no longer pending")
        used = {r["slot"] for r in conn.execute(
            "SELECT slot FROM devices WHERE role='sender'"
        ).fetchall()}
        free_slot = next((slot for slot in ("sender-1", "sender-2") if slot not in used), None)
        if free_slot is None:
            raise HTTPException(status_code=409, detail="Maximum of two active senders reached")
        conn.execute(
            "INSERT INTO devices(device_key, role, slot, last_seen, enabled) VALUES(?, 'sender', ?, 0, 1)",
            (row["credential_hash"], free_slot)
        )
        conn.execute(
            "UPDATE enrollment_requests SET state='approved', decided_at=? WHERE request_id=?",
            (int(time.time()), request_id)
        )
    return {"ok": True, "request_id": request_id, "state": "approved", "sender_slot": free_slot}

@app.post("/v1/enrollments/{request_id}/reject")
def reject_enrollment(request_id: str, authorization: Optional[str] = Header(default=None)):
    role, _ = authenticate(authorization)
    if role != "receiver":
        raise HTTPException(status_code=403, detail="Only receiver can reject devices")
    with db() as conn:
        cur = conn.execute(
            "UPDATE enrollment_requests SET state='rejected', decided_at=? "
            "WHERE request_id=? AND state='pending'",
            (int(time.time()), request_id)
        )
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="Pending request not found")
    return {"ok": True, "request_id": request_id, "state": "rejected"}

@app.post("/v1/heartbeat")
def heartbeat(body: Heartbeat, authorization: Optional[str] = Header(default=None)):
    role, slot = authenticate(authorization)
    return {"ok": True, "role": role, "slot": slot, "server_time": int(time.time())}

@app.post("/v1/batches")
async def upload_batch(body: EncryptedBatch, request: Request,
                       authorization: Optional[str] = Header(default=None)):
    role, slot = authenticate(authorization)
    if role != "sender":
        raise HTTPException(status_code=403, detail="Only senders can upload batches")
    if len(body.ciphertext.encode()) > MAX_PAYLOAD_BYTES:
        raise HTTPException(status_code=413, detail="Encrypted batch too large")
    # Reject accidental plaintext JSON-shaped payloads as a guardrail, not a crypto proof.
    with db() as conn:
        try:
            cur = conn.execute(
                """INSERT INTO batches(batch_uuid, sender_slot, ciphertext, created_at)
                   VALUES(?, ?, ?, ?)""",
                (body.batch_id, slot, body.ciphertext, int(time.time()))
            )
            batch_id = cur.lastrowid
        except sqlite3.IntegrityError:
            row = conn.execute("SELECT id FROM batches WHERE batch_uuid=?",
                               (body.batch_id,)).fetchone()
            batch_id = row["id"]
    return {"ok": True, "stored": True, "batch_id": batch_id, "sender_slot": slot}

@app.get("/v1/batches")
def pending_batches(limit: int = Query(default=50, ge=1, le=200),
                    authorization: Optional[str] = Header(default=None)):
    role, _ = authenticate(authorization)
    if role != "receiver":
        raise HTTPException(status_code=403, detail="Only receiver can download batches")
    with db() as conn:
        rows = conn.execute(
            """SELECT id, batch_uuid, sender_slot, ciphertext, created_at
               FROM batches WHERE delivered=0 ORDER BY id LIMIT ?""",
            (limit,)
        ).fetchall()
    return {"ok": True, "batches": [dict(row) for row in rows]}

@app.post("/v1/batches/ack")
def acknowledge(body: AckBody, authorization: Optional[str] = Header(default=None)):
    role, _ = authenticate(authorization)
    if role != "receiver":
        raise HTTPException(status_code=403, detail="Only receiver can acknowledge")
    with db() as conn:
        conn.executemany(
            "UPDATE batches SET delivered=1 WHERE batch_uuid=?",
            [(item,) for item in body.batch_ids]
        )
    return {"ok": True, "acknowledged": len(body.batch_ids)}

@app.get("/v1/status")
def status(authorization: Optional[str] = Header(default=None)):
    role, _ = authenticate(authorization)
    if role != "receiver":
        raise HTTPException(status_code=403, detail="Only receiver can view device status")
    now = int(time.time())
    with db() as conn:
        devices = conn.execute(
            "SELECT slot, role, last_seen, enabled FROM devices ORDER BY slot"
        ).fetchall()
        pending = conn.execute(
            "SELECT sender_slot, COUNT(*) AS count FROM batches WHERE delivered=0 GROUP BY sender_slot"
        ).fetchall()
    pending_map = {row["sender_slot"]: row["count"] for row in pending}
    return {
        "ok": True,
        "devices": [
            {
                "slot": row["slot"],
                "role": row["role"],
                "enabled": bool(row["enabled"]),
                "last_seen": row["last_seen"],
                "online": bool(row["last_seen"] and now - row["last_seen"] <= ONLINE_SECONDS),
                "pending_batches": pending_map.get(row["slot"], 0),
            } for row in devices
        ]
    }

@app.post("/v1/control")
def control(body: ControlBody, authorization: Optional[str] = Header(default=None)):
    role, _ = authenticate(authorization)
    if role != "receiver":
        raise HTTPException(status_code=403, detail="Only receiver can control senders")
    with db() as conn:
        cur = conn.execute(
            "UPDATE devices SET enabled=? WHERE slot=? AND role='sender'",
            (1 if body.enabled else 0, body.sender_slot)
        )
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="Sender slot not provisioned")
    return {"ok": True, "sender_slot": body.sender_slot, "enabled": body.enabled}

@app.exception_handler(Exception)
async def unexpected_error_handler(request: Request, exc: Exception):
    # Do not expose internal exception details or credentials to clients.
    return JSONResponse(status_code=500, content={"detail": "Internal server error"})
