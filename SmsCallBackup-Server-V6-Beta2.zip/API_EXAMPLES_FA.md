# نمونه درخواست‌ها

همه درخواست‌ها پس از استقرار باید از HTTPS باشند.

## سلامت
`GET /health`

## ضربان دستگاه
`POST /v1/heartbeat`
Header: `Authorization: Bearer <DEVICE_TOKEN>`
Body:
`{"app_version":"0.1.0","platform":"android"}`

## ارسال بسته (Sender)
`POST /v1/batches`
Header: `Authorization: Bearer <SENDER_TOKEN>`
Body:
`{"batch_id":"unique-batch-0001","ciphertext":"BASE64_OR_OPAQUE_CIPHERTEXT"}`

## دریافت بسته‌ها (Receiver)
`GET /v1/batches?limit=50`
Header: `Authorization: Bearer <RECEIVER_TOKEN>`

## تأیید دریافت
`POST /v1/batches/ack`
Header: `Authorization: Bearer <RECEIVER_TOKEN>`
Body:
`{"batch_ids":["unique-batch-0001"]}`

## وضعیت
`GET /v1/status`
Header: `Authorization: Bearer <RECEIVER_TOKEN>`

## کنترل Sender
`POST /v1/control`
Header: `Authorization: Bearer <RECEIVER_TOKEN>`
Body:
`{"sender_slot":"sender-1","enabled":false}`
